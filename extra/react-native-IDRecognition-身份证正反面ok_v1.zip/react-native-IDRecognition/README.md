# IDCardRecognition
Android 身份证号码识别 （本地，在线，实时）

### 网络识别用的别人的接口，不保障什么时候就用不了了，本地识别基于tess_two，位置对的话识别准确率达到90%以上

![](http://tu.bertsir.top/images/2017/09/28/IDCrad.jpg)

使用方法：https://www.jianshu.com/p/80066665268a

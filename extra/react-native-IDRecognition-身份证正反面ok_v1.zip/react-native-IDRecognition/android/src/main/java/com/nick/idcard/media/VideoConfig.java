package com.nick.idcard.media;

/**
 * Created by rusfearuth on 16.03.17.
 */

public class VideoConfig
{
}
